from __future__ import (absolute_import, division,
                        print_function, unicode_literals)
from builtins import *
from tkinter import *
from pprint import pprint
import random
import googlemaps

API_KEY = "AIzaSyAa4_hAVYXtJWtgfB_prsPxhnTaWrFdemM"

map_client = googlemaps.Client(API_KEY)


def script():
    food_types = ['chinese', 'Pizza', 'Spanish food', 'Mexican', 'burgers', 'ice cream', 'tacos', 'smoothies',
                  "Gluten free"]
    pick = random.choice(food_types)
    response = map_client.places(pick)
    results = response.get('results')
    res = results[0]
    geometry = res.get('geometry')
    location = geometry.get('location')
    search_completed = map_client.places_nearby(location, radius=50)
    results_restaurants = search_completed.get('results')
    restaurants_found = results[0] or results[1]
    restaurants_name = restaurants_found.get('name')
    print("We found this restaurant: ", restaurants_name)
    return restaurants_name
    exit()


root = Tk()
root.title('Food Picker')
root.geometry("400x200")
# Making a label
mylabel = Label(root, text="What food do we want to eat today?")
# Showing it on screen
mylabel.pack()
mylabel2 = Label(root, text="Here are some foods that are available within 50KM!")

def printingrestaurant():
    mylabel2.config(text=script())


button = Button(root, text="Generate", padx=50, command=printingrestaurant, fg="blue")
button.pack(pady=10)
mylabel2.pack(pady=10)
root.mainloop()
